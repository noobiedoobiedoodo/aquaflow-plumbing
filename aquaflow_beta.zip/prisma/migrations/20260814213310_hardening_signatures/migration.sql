/*
  Warnings:

  - You are about to drop the column `signatureBlob` on the `CustomerSignature` table. All the data in the column will be lost.
  - Added the required column `storageKey` to the `CustomerSignature` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_CustomerSignature" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "jobId" TEXT NOT NULL,
    "signerName" TEXT NOT NULL,
    "storageKey" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "CustomerSignature_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES "Job" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_CustomerSignature" ("createdAt", "id", "jobId", "signerName") SELECT "createdAt", "id", "jobId", "signerName" FROM "CustomerSignature";
DROP TABLE "CustomerSignature";
ALTER TABLE "new_CustomerSignature" RENAME TO "CustomerSignature";
CREATE UNIQUE INDEX "CustomerSignature_jobId_key" ON "CustomerSignature"("jobId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
