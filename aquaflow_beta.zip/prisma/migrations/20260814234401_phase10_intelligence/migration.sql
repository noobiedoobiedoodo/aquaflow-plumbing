-- AlterTable
ALTER TABLE "Technician" ADD COLUMN "currentLat" REAL;
ALTER TABLE "Technician" ADD COLUMN "currentLng" REAL;
ALTER TABLE "Technician" ADD COLUMN "locationUpdatedAt" DATETIME;

-- CreateTable
CREATE TABLE "IntelligenceRecommendation" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "organizationId" TEXT NOT NULL,
    "jobId" TEXT NOT NULL,
    "technicianId" TEXT NOT NULL,
    "score" REAL NOT NULL,
    "distanceScore" REAL NOT NULL,
    "availabilityScore" REAL NOT NULL,
    "skillScore" REAL NOT NULL,
    "workloadScore" REAL NOT NULL,
    "distanceKm" REAL,
    "availabilityStatus" TEXT NOT NULL,
    "skillMatch" TEXT NOT NULL,
    "workloadLevel" TEXT NOT NULL,
    "reasoningJson" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'SUGGESTED',
    "scoringVersion" TEXT NOT NULL DEFAULT 'v1.0',
    "feedbackReason" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "IntelligenceRecommendation_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "IntelligenceRecommendation_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES "Job" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "IntelligenceRecommendation_technicianId_fkey" FOREIGN KEY ("technicianId") REFERENCES "Technician" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "IntelligenceRecommendation_jobId_status_idx" ON "IntelligenceRecommendation"("jobId", "status");
