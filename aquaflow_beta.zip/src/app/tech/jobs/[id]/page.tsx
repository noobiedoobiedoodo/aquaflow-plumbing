import { requireAuth } from '@/lib/auth/session';
import { prisma } from '@/lib/db';
import { notFound, redirect } from 'next/navigation';
import { JobWorkspace } from './JobWorkspace';
import { ROLES, ADMIN_ROLES } from '@/lib/constants';

export default async function JobPage({ params }: { params: { id: string } }) {
  const { user } = await requireAuth();

  const { id } = await params;

  const job = await prisma.job.findUnique({
    where: { id },
    include: {
      appointment: {
        include: {
          property: true,
          customer: true,
        },
      },
      timeEntries: {
        where: { technicianId: user.id },
        orderBy: { startedAt: 'asc' },
      },
      parts: true,
      notes: {
        orderBy: { createdAt: 'desc' },
        include: { author: { select: { firstName: true, lastName: true } } },
      },
      photos: {
        orderBy: { createdAt: 'desc' },
      },
      signature: true,
    },
  });

  if (!job) notFound();

  // Enforce assignment constraints
  const isTechnician = user.memberships.some((m) => m.role === ROLES.TECHNICIAN);
  const isAdmin = user.memberships.some((m) => ADMIN_ROLES.includes(m.role as any));

  if (isTechnician && !isAdmin) {
    if (job.technicianId !== user.id) {
      redirect('/tech/dashboard'); // Or show an unauthorized error
    }
  }

  return <JobWorkspace job={job} user={user} />;
}
