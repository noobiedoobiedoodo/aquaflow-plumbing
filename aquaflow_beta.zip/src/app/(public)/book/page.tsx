import { prisma } from '@/lib/db';
import { BookingWizard } from '@/components/booking/BookingWizard';

export const metadata = {
  title: 'Book Service | AquaFlow Plumbing',
  description: 'Request a plumbing appointment or emergency service online.',
};

export default async function BookPage() {
  const services = await prisma.service.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: 'asc' },
    select: {
      id: true,
      name: true,
      shortDescription: true,
      icon: true,
      isEmergency: true,
    }
  });

  return (
    <div className="min-h-screen bg-background relative overflow-hidden pt-12 pb-24">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-primary-blue/5 rounded-full blur-[120px] -z-10 pointer-events-none"></div>
      
      <div className="container mx-auto px-4 max-w-4xl relative z-10">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Request Service</h1>
          <p className="text-muted-text text-lg">We'll get you the right technician as quickly as possible.</p>
        </div>

        <BookingWizard services={services} />
      </div>
    </div>
  );
}
