import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth/session';
import { getCustomerSession } from '@/lib/auth/customer-session';
import { join } from 'path';
import { existsSync } from 'fs';
import { readFile } from 'fs/promises';
import mime from 'mime';

import { ROLES, ADMIN_ROLES } from '@/lib/constants';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest, { params }: { params: Promise<{ key: string }> }) {
  try {
    const { key } = await params;

    if (!key || key.includes('..') || key.includes('/') || key.includes('\\')) {
      return new NextResponse('Invalid file key', { status: 400 });
    }

    // 1. Verify Authentication & Authorization
    const currentUser = await getCurrentUser();
    const currentCustomer = await getCustomerSession();

    if (!currentUser && !currentCustomer) {
      return new NextResponse('Unauthorized', { status: 401 });
    }

    // Determine the nature of the file
    const signature = await prisma.customerSignature.findFirst({ where: { storageKey: key }, include: { job: { include: { appointment: true, technician: true } } } });
    const photo = await prisma.jobPhoto.findFirst({ where: { storageKey: key }, include: { job: { include: { appointment: true, technician: true } } } });

    const job = signature?.job || photo?.job;

    if (!job || !job.appointment) {
      return new NextResponse('File association not found or unauthorized', { status: 403 });
    }

    // Apply Customer Rules
    if (currentCustomer && !currentUser) {
      if (job.appointment.customerId !== currentCustomer.customerId) {
        return new NextResponse('Forbidden: You do not own this file', { status: 403 });
      }

      if (photo && !photo.customerVisible) {
        return new NextResponse('Forbidden: This photo is not available to customers', { status: 403 });
      }
    }

    // Apply Technician Rules
    if (currentUser) {
      const { user } = currentUser;
      const isTechnician = user.memberships.some((m) => m.role === ROLES.TECHNICIAN);
      const isAdmin = user.memberships.some((m) => ADMIN_ROLES.includes(m.role as any));

      if (isTechnician && !isAdmin) {
        if (job.technician?.userId !== user.id) {
          return new NextResponse('Forbidden: You are not assigned to the job associated with this file', { status: 403 });
        }
      }
    }

    // 2. Resolve File Path

    const filePath = join(process.cwd(), 'storage', 'private', key);

    if (!existsSync(filePath)) {
      return new NextResponse('File not found', { status: 404 });
    }

    // 3. Read and Serve File
    const fileBuffer = await readFile(filePath);
    const mimeType = mime.getType(filePath) || 'application/octet-stream';

    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        'Content-Type': mimeType,
        'Cache-Control': 'private, max-age=3600',
      },
    });
  } catch (error: any) {
    console.error('Error serving file:', error);
    if (error.message === 'Unauthorized' || error.message === 'Forbidden') {
      return new NextResponse('Unauthorized', { status: 401 });
    }
    return new NextResponse('Internal Server Error', { status: 500 });
  }
}
