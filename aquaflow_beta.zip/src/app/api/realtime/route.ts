import { NextRequest } from 'next/server';
import { requireRole } from '@/lib/auth/session';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  // Authorize
  const { user } = await requireRole(['ADMIN', 'SUPER_ADMIN', 'DISPATCHER']);
  const organizationId = user.memberships[0]?.organizationId; // Grab first org for MVP

  if (!organizationId) {
    return new Response('Unauthorized', { status: 403 });
  }

  // Set up SSE headers
  const headers = new Headers({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
  });

  const stream = new ReadableStream({
    async start(controller) {
      // In a real MVP with Redis, we would subscribe to a Redis pub/sub channel here.
      // For this Next.js app without an active Redis client in this file, we can simulate 
      // the real-time event pipeline by polling the database's recent events or simply 
      // keeping the connection open for the client to receive periodic pings.
      // Since Phase 11 requested real-time, we provide the SSE endpoint.
      
      const sendEvent = (data: any) => {
        controller.enqueue(`data: ${JSON.stringify(data)}\n\n`);
      };

      sendEvent({ type: 'CONNECTED' });

      // Simulate a database listener or Redis subscriber
      const interval = setInterval(async () => {
        try {
          // Poll for tasks created in the last 10 seconds just to simulate real-time push
          const recentTasks = await prisma.task.findMany({
            where: { 
              createdAt: { gt: new Date(Date.now() - 10000) },
              organizationId
            }
          });

          if (recentTasks.length > 0) {
            sendEvent({ type: 'NEW_TASKS', tasks: recentTasks });
          } else {
             // Keep-alive ping
             sendEvent({ type: 'PING', time: new Date().toISOString() });
          }
        } catch (err) {
          // Ignore
        }
      }, 10000);

      req.signal.addEventListener('abort', () => {
        clearInterval(interval);
        controller.close();
      });
    }
  });

  return new Response(stream, { headers });
}
