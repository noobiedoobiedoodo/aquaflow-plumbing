import { NextResponse } from 'next/server';
import { requireAuth } from '@/lib/auth/session';
import { prisma } from '@/lib/db';
import { stripe } from '@/lib/stripe';

export async function POST(req: Request) {
  try {
    const { user } = await requireAuth();

    const membership = await prisma.organizationMember.findFirst({
      where: { userId: user.id },
      include: { organization: true },
    });

    if (!membership) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    const org = membership.organization;

    if (!process.env.STRIPE_SECRET_KEY) {
      return NextResponse.json({ error: 'Stripe is not configured.' }, { status: 500 });
    }

    let accountId = org.stripeAccountId;

    // 1. Create a Stripe Connected Account if one doesn't exist
    if (!accountId) {
      const account = await stripe.accounts.create({
        type: 'standard',
        email: org.email || user.email,
        business_profile: {
          name: org.name,
          url: org.domain ? `https://${org.domain}` : undefined,
        },
      });
      accountId = account.id;

      await prisma.organization.update({
        where: { id: org.id },
        data: {
          stripeAccountId: accountId,
          stripeConnectionStatus: 'PENDING',
        }
      });
    }

    // 2. Create an AccountLink for onboarding
    const accountLink = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: `${process.env.NEXT_PUBLIC_APP_URL}/api/stripe-connect/refresh`,
      return_url: `${process.env.NEXT_PUBLIC_APP_URL}/api/stripe-connect/callback`,
      type: 'account_onboarding',
    });

    return NextResponse.redirect(accountLink.url, 303);

  } catch (err: any) {
    console.error('Stripe Connect Error:', err);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
