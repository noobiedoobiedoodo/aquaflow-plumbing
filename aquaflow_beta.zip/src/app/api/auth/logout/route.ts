import { NextResponse } from 'next/server';
import { getSessionFromCookies, revokeSession, clearSessionCookie } from '@/lib/auth/session';

export async function POST() {
  try {
    const token = await getSessionFromCookies();

    if (token) {
      await revokeSession(token);
    }

    await clearSessionCookie();

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
