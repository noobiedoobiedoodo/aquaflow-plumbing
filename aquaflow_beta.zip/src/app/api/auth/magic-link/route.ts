import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { randomBytes, createHash } from 'crypto';
import { hashToken } from '@/lib/auth/customer-session';
import { RateLimiter, RATE_LIMITS } from '@/lib/security/rate-limiter';

export async function POST(req: Request) {
  try {
    const { email } = await req.json();
    if (!email) return new NextResponse('Email is required', { status: 400 });

    const ip = await RateLimiter.getClientIp();
    
    // Rate Limiting
    const isAllowed = await RateLimiter.checkMulti([ip, email.toLowerCase()], RATE_LIMITS.LOGIN);
    if (!isAllowed) {
      return new NextResponse('Too many requests. Please try again later.', { status: 429 });
    }

    // Always return a generic success message to prevent account enumeration
    const successResponse = NextResponse.json({ 
      message: 'If an account exists, a sign-in link has been sent to this email.' 
    });

    const user = await prisma.user.findUnique({
      where: { email },
      include: { customer: true }
    });

    if (!user || !user.customer) {
      // Simulate delay to prevent timing attacks
      await new Promise(r => setTimeout(r, 500));
      return successResponse;
    }

    // Generate Token
    const rawToken = randomBytes(32).toString('base64url');
    const tokenHash = hashToken(rawToken);

    // Store in DB (15 min expiry)
    await prisma.magicLinkToken.create({
      data: {
        userId: user.id,
        tokenHash,
        expiresAt: new Date(Date.now() + 15 * 60 * 1000),
      }
    });

    // Send via Outbox/Event system or directly via Resend for MVP
    // To integrate with our existing notification system cleanly:
    const magicLinkUrl = `${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/auth/verify?token=${rawToken}`;
    
    await prisma.notification.create({
      data: {
        organizationId: user.customer.organizationId,
        idempotencyKey: `magiclink:${tokenHash}`,
        userId: user.id,
        type: 'MAGIC_LINK',
        channel: 'EMAIL',
        status: 'PENDING',
        subject: 'Your AquaFlow Sign-in Link',
        content: `Hi ${user.firstName || 'Customer'},\n\nClick here to securely sign in to your portal. This link expires in 15 minutes.\n\n${magicLinkUrl}`,
        metadata: JSON.stringify({ email: user.email }),
      }
    });

    return successResponse;

  } catch (error) {
    console.error('Magic link generation error:', error);
    return new NextResponse('Internal Server Error', { status: 500 });
  }
}
