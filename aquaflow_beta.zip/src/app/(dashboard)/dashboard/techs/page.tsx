export default function TechsPage() {
  return (
    <div className="glass p-8 rounded-2xl border border-border/50 h-[800px] flex flex-col items-center justify-center text-center">
      <h1 className="text-2xl font-bold text-white mb-2">Technicians</h1>
      <p className="text-muted-text">This view is coming in a future phase.</p>
    </div>
  );
}
