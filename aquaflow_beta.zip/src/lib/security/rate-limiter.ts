import { redis } from '@/lib/config/redis';
import { headers } from 'next/headers';

export interface RateLimitConfig {
  action: string;
  maxRequests: number;
  windowSeconds: number;
}

export const RATE_LIMITS = {
  BOOKING: { action: 'booking', maxRequests: 5, windowSeconds: 3600 }, // 5 per hour per IP/Email
  LOGIN: { action: 'login', maxRequests: 10, windowSeconds: 900 }, // 10 per 15 min per IP/Email
  WEBHOOK: { action: 'webhook', maxRequests: 100, windowSeconds: 60 }, // 100 per minute per Org
  API: { action: 'api_general', maxRequests: 1000, windowSeconds: 3600 },
};

export class RateLimiter {
  /**
   * Checks if a request exceeds the limit.
   * Uses a basic sliding window counter in Redis.
   * @param identifier - e.g. IP address, user ID, or organization ID
   * @param config - RateLimitConfig
   * @returns boolean true if allowed, false if blocked
   */
  static async check(identifier: string, config: RateLimitConfig): Promise<boolean> {
    if (!redis) {
      console.warn('Redis not available, bypassing rate limit for', config.action);
      return true; // Bypass if redis is missing (e.g. dev environment without redis)
    }

    const key = `rate_limit:${config.action}:${identifier}`;
    
    // Increment the counter
    const current = await redis.incr(key);

    if (current === 1) {
      // If it's the first request in the window, set the expiry
      await redis.expire(key, config.windowSeconds);
    }

    if (current > config.maxRequests) {
      return false;
    }

    return true;
  }

  /**
   * Gets the client IP from Next.js headers safely
   */
  static async getClientIp(): Promise<string> {
    const headersList = await headers();
    const forwardedFor = headersList.get('x-forwarded-for');
    if (forwardedFor) {
      return forwardedFor.split(',')[0].trim();
    }
    return headersList.get('x-real-ip') || '127.0.0.1';
  }

  /**
   * Multi-dimensional rate limit check.
   * e.g. check by IP AND by CustomerEmail
   */
  static async checkMulti(identifiers: string[], config: RateLimitConfig): Promise<boolean> {
    for (const id of identifiers) {
      if (!id) continue;
      const allowed = await this.check(id, config);
      if (!allowed) return false;
    }
    return true;
  }
}
