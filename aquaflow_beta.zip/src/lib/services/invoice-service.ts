import { prisma } from '@/lib/db';
import { randomBytes } from 'crypto';

export class InvoiceService {
  /**
   * Generates a final invoice for a completed job.
   */
  static async generateInvoice(organizationId: string, jobId: string) {
    const job = await prisma.job.findUnique({
      where: { id: jobId, organizationId },
      include: {
        appointment: { include: { service: true } },
        parts: true,
        timeEntries: true,
      }
    });

    if (!job) throw new Error('Job not found');
    if (job.status !== 'COMPLETED') throw new Error('Cannot invoice an incomplete job');

    const existingInvoice = await prisma.invoice.findFirst({
      where: { jobId, organizationId }
    });

    if (existingInvoice) throw new Error('Invoice already exists for this job');

    // Calculate labor costs (placeholder logic)
    const laborRate = 120.0; // $120/hr
    const totalMinutes = job.timeEntries.reduce((acc, entry) => {
      if (!entry.endedAt) return acc;
      const mins = (new Date(entry.endedAt).getTime() - new Date(entry.startedAt).getTime()) / 60000;
      return acc + mins;
    }, 0);
    const laborCost = (totalMinutes / 60) * laborRate;

    // Calculate parts cost
    const partsCost = job.parts.reduce((acc, part) => acc + (part.unitCost * part.quantity), 0);

    const subtotal = laborCost + partsCost;
    const taxRate = 0.05; // Fetch from organization
    const tax = subtotal * taxRate;
    const total = subtotal + tax;

    const paymentToken = randomBytes(32).toString('hex');
    const invoiceNumber = `INV-${new Date().getFullYear()}-${Math.floor(Math.random() * 100000).toString().padStart(5, '0')}`;

    // Execute within a transaction
    return await prisma.$transaction(async (tx) => {
      const invoice = await tx.invoice.create({
        data: {
          invoiceNumber,
          organizationId,
          jobId,
          customerId: job.appointment.customerId,
          status: 'SENT', // Immediately transition to SENT for touchless billing MVP
          subtotal,
          taxTotal: tax,
          total,
          paymentToken,
          dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days
          lines: {
            create: [
              { description: 'Labor', quantity: totalMinutes / 60, unitCost: laborRate },
              ...job.parts.map(p => ({ description: p.name, quantity: p.quantity, unitCost: p.unitCost }))
            ]
          }
        }
      });

      // Insert Financial Activity
      await tx.financialActivity.create({
        data: {
          invoiceId: invoice.id,
          event: 'INVOICE_GENERATED',
          metadata: JSON.stringify({ source: 'AutomationEngine', amount: total })
        }
      });

      // Outbox Event
      await tx.event.create({
        data: {
          organizationId,
          type: 'invoice.generated',
          entityType: 'Invoice',
          entityId: invoice.id,
          data: JSON.stringify({ invoiceId: invoice.id, customerId: invoice.customerId, total })
        }
      });

      return invoice;
    });
  }
}
