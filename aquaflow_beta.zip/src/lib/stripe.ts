import Stripe from 'stripe';

if (!process.env.STRIPE_SECRET_KEY) {
  // We won't throw immediately here because this file might be imported in environments
  // where the key isn't strictly necessary until a payment route is hit.
  console.warn('STRIPE_SECRET_KEY is not set in environment variables.');
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_mock', {
  // https://github.com/stripe/stripe-node#configuration
  apiVersion: '2024-06-20' as any, // Use the latest API version or your account's default
  appInfo: {
    name: 'AquaFlow Plumbing',
    url: 'https://aquaflowplumbing.com',
  },
});
