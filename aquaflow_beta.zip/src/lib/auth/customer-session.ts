import { cookies } from 'next/headers';
import { prisma } from '@/lib/db';
import { randomBytes, createHash } from 'crypto';
import { redirect } from 'next/navigation';

const CUSTOMER_SESSION_COOKIE = 'customer_session';
const SESSION_DURATION_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

export function hashToken(token: string) {
  return createHash('sha256').update(token).digest('hex');
}

export async function createCustomerSession(customerId: string) {
  const token = randomBytes(32).toString('base64url');
  const tokenHash = hashToken(token);
  
  await prisma.customerSession.create({
    data: {
      customerId,
      tokenHash,
      expiresAt: new Date(Date.now() + SESSION_DURATION_MS),
    }
  });

  const cookieStore = await cookies();
  cookieStore.set(CUSTOMER_SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    expires: new Date(Date.now() + SESSION_DURATION_MS),
    path: '/',
  });

  await prisma.customerActivity.create({
    data: {
      customerId,
      action: 'CUSTOMER_LOGIN',
    }
  });

  return token;
}

export async function getCustomerSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(CUSTOMER_SESSION_COOKIE)?.value;

  if (!token) return null;

  const tokenHash = hashToken(token);
  const session = await prisma.customerSession.findUnique({
    where: { tokenHash },
    include: { customer: true }
  });

  if (!session) return null;
  if (session.revokedAt || session.expiresAt < new Date()) {
    return null;
  }

  // Update lastUsedAt in background without blocking the request
  prisma.customerSession.update({
    where: { id: session.id },
    data: { lastUsedAt: new Date() }
  }).catch(() => {});

  return {
    customerId: session.customerId,
    customer: session.customer,
    sessionId: session.id,
  };
}

export async function requireCustomerSession() {
  const session = await getCustomerSession();
  if (!session) {
    redirect('/portal/login');
  }
  return session;
}

export async function revokeCustomerSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(CUSTOMER_SESSION_COOKIE)?.value;

  if (token) {
    const tokenHash = hashToken(token);
    await prisma.customerSession.updateMany({
      where: { tokenHash },
      data: { revokedAt: new Date() }
    });
    
    cookieStore.delete(CUSTOMER_SESSION_COOKIE);
  }
  redirect('/portal/login');
}
