import { cookies } from 'next/headers';
import { prisma } from '@/lib/db';
import { generateToken } from '@/lib/utils';
import { Role } from '@/lib/constants';

const SESSION_COOKIE_NAME = 'plumber-session';
const SESSION_MAX_AGE_DAYS = Number(process.env.SESSION_MAX_AGE_DAYS) || 30;

/**
 * Creates a new session in the database.
 */
export async function createSession(userId: string, ipAddress?: string, userAgent?: string) {
  const token = generateToken();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + SESSION_MAX_AGE_DAYS);

  await prisma.session.create({
    data: {
      userId,
      token,
      expiresAt,
      ipAddress,
      userAgent,
    },
  });

  return token;
}

/**
 * Validates a session token and returns the session and user if valid.
 */
export async function validateSession(token: string) {
  const session = await prisma.session.findUnique({
    where: { token },
    include: {
      user: {
        include: {
          memberships: {
            include: {
              organization: true,
            }
          },
        },
      },
    },
  });

  if (!session) return null;
  if (session.revokedAt) return null;
  if (new Date() > session.expiresAt) return null;
  if (!session.user.isActive) return null;

  return session;
}

/**
 * Revokes a specific session.
 */
export async function revokeSession(token: string) {
  await prisma.session.update({
    where: { token },
    data: { revokedAt: new Date() },
  });
}

/**
 * Revokes all active sessions for a user.
 */
export async function revokeAllUserSessions(userId: string) {
  await prisma.session.updateMany({
    where: {
      userId,
      revokedAt: null,
    },
    data: { revokedAt: new Date() },
  });
}

/**
 * Gets the session token from cookies.
 */
export async function getSessionFromCookies(): Promise<string | undefined> {
  const cookieStore = await cookies();
  const sessionCookie = cookieStore.get(SESSION_COOKIE_NAME);
  return sessionCookie?.value;
}

/**
 * Sets the session cookie.
 */
export async function setSessionCookie(token: string) {
  const expires = new Date();
  expires.setDate(expires.getDate() + SESSION_MAX_AGE_DAYS);

  const cookieStore = await cookies();
  cookieStore.set({
    name: SESSION_COOKIE_NAME,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    expires,
  });
}

/**
 * Clears the session cookie.
 */
export async function clearSessionCookie() {
  const cookieStore = await cookies();
  cookieStore.set({
    name: SESSION_COOKIE_NAME,
    value: '',
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    expires: new Date(0),
  });
}

/**
 * Gets the current authenticated user and their active session.
 */
export async function getCurrentUser() {
  const token = await getSessionFromCookies();
  if (!token) return null;

  const session = await validateSession(token);
  if (!session) return null;

  return {
    user: session.user,
    session,
  };
}

/**
 * Requires an authenticated user. Throws if not authenticated.
 */
export async function requireAuth() {
  const current = await getCurrentUser();
  if (!current) {
    throw new Error('Unauthorized');
  }
  return current;
}

/**
 * Requires a specific role. Throws if user does not have the role in the organization.
 */
export async function requireRole(roles: Role[], organizationId?: string) {
  const current = await requireAuth();

  // If organizationId is provided, check if the user has the role in that specific organization
  if (organizationId) {
    const hasRole = current.user.memberships.some(
      (m) => m.organizationId === organizationId && roles.includes(m.role as Role)
    );
    if (!hasRole) {
      throw new Error('Forbidden');
    }
  } else {
    // If no organizationId, just check if they have the role in ANY organization
    // (useful for global actions or when organization context isn't strictly required but role is)
    const hasRole = current.user.memberships.some((m) => roles.includes(m.role as Role));
    if (!hasRole) {
      throw new Error('Forbidden');
    }
  }

  return current;
}

/**
 * Requires a specific role and returns the user's verified organizationId.
 * 
 * CRITICAL: This is the primary tenant isolation boundary.
 * The organizationId is ALWAYS derived from the authenticated session, never from client input.
 * All tenant-scoped queries MUST use the organizationId returned by this function.
 */
export async function requireRoleInOrg(roles: Role[]) {
  const current = await requireAuth();

  // Find the first membership matching one of the required roles
  const membership = current.user.memberships.find((m) => roles.includes(m.role as Role));
  if (!membership) {
    throw new Error('Forbidden');
  }

  return {
    user: current.user,
    session: current.session,
    organizationId: membership.organizationId,
  };
}

/**
 * Validates that the organization has an active or grace-period subscription.
 * Throws if the subscription is CANCELED, UNPAID, or INCOMPLETE.
 */
export async function requireActiveSubscription(organizationId: string) {
  const current = await requireAuth();
  
  const membership = current.user.memberships.find(m => m.organizationId === organizationId);
  if (!membership) throw new Error('Forbidden');

  const status = (membership.organization as { subscriptionStatus?: string | null })?.subscriptionStatus;
  
  // No status means they haven't subscribed at all (or local dev)
  if (!status) return current;

  // Canceled or Unpaid restrict mutations
  if (['CANCELED', 'UNPAID', 'INCOMPLETE', 'INCOMPLETE_EXPIRED'].includes(status)) {
    throw new Error('Subscription inactive. Your account is currently in read-only mode.');
  }

  return current;
}
