/**
 * File Storage Abstraction
 * Allows switching between local storage (for development) and S3 (for production)
 * without rewriting the application logic.
 */

export interface FileStorageProvider {
  /**
   * Uploads a file buffer and returns a unique storage key and a public URL (if applicable).
   */
  uploadFile(file: Buffer, fileName: string, mimeType: string): Promise<{ storageKey: string; url: string }>;
  
  /**
   * Deletes a file by its storage key.
   */
  deleteFile(storageKey: string): Promise<void>;
  
  /**
   * Gets a signed URL or public URL for a storage key.
   */
  getFileUrl(storageKey: string): Promise<string>;
}

// ==========================================
// Local File Storage Provider (Development)
// ==========================================
import { writeFileSync, unlinkSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

export class LocalFileStorageProvider implements FileStorageProvider {
  private baseDir: string;
  private baseUrl: string;

  constructor() {
    // Store files securely outside the public directory so they cannot be accessed directly
    this.baseDir = join(process.cwd(), 'storage', 'private');
    // The URLs will be served through the authenticated API route
    this.baseUrl = '/api/files';
    
    if (!existsSync(this.baseDir)) {
      mkdirSync(this.baseDir, { recursive: true });
    }
  }

  async uploadFile(file: Buffer, fileName: string, mimeType: string) {
    const uniqueFileName = `${Date.now()}-${Math.random().toString(36).substring(7)}-${fileName}`;
    const filePath = join(this.baseDir, uniqueFileName);
    
    writeFileSync(filePath, file);
    
    return {
      storageKey: uniqueFileName,
      url: `${this.baseUrl}/${uniqueFileName}`
    };
  }

  async deleteFile(storageKey: string) {
    const filePath = join(this.baseDir, storageKey);
    if (existsSync(filePath)) {
      unlinkSync(filePath);
    }
  }

  async getFileUrl(storageKey: string) {
    return `${this.baseUrl}/${storageKey}`;
  }
}

// ==========================================
// S3 File Storage Provider (Production)
// ==========================================
export class S3FileStorageProvider implements FileStorageProvider {
  // Mock implementation for the MVP.
  // In a real scenario, this would use @aws-sdk/client-s3

  async uploadFile(file: Buffer, fileName: string, mimeType: string) {
    const storageKey = `s3-mock-${Date.now()}-${fileName}`;
    console.log(`[S3 Mock] Uploaded ${fileName} to bucket`);
    return {
      storageKey,
      url: `https://mock-s3-bucket.s3.amazonaws.com/${storageKey}`
    };
  }

  async deleteFile(storageKey: string) {
    console.log(`[S3 Mock] Deleted ${storageKey} from bucket`);
  }

  async getFileUrl(storageKey: string) {
    return `https://mock-s3-bucket.s3.amazonaws.com/${storageKey}`;
  }
}

// ==========================================
// Singleton Factory
// ==========================================
export function getStorageProvider(): FileStorageProvider {
  // For this MVP, if an S3 bucket is configured, use S3, else use Local
  if (process.env.AWS_S3_BUCKET_NAME) {
    return new S3FileStorageProvider();
  }
  return new LocalFileStorageProvider();
}

export const storage = getStorageProvider();
