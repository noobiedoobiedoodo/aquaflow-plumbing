import { Worker, Job } from 'bullmq';
import { prisma } from '../lib/db';
import { redis } from '../lib/queue/redis';
import { QUEUES, EventQueueJobData, notificationsQueue } from '../lib/queue/bullmq';
import { AutomationRulesEngine } from '../lib/automation/rules-engine';

async function processEvent(job: Job<EventQueueJobData>) {
  const { eventId } = job.data;

  console.log(`Processing Event ${eventId} (Type: ${job.name})`);

  const event = await prisma.event.findUnique({
    where: { id: eventId },
    include: { organization: true }
  });

  if (!event) throw new Error(`Event ${eventId} not found`);

  try {
    // Execute Automation Rules Engine
    await AutomationRulesEngine.evaluateEvent(event.id);

    // Mark Event as COMPLETED
    await prisma.event.update({
      where: { id: eventId },
      data: { status: 'COMPLETED', processedAt: new Date() }
    });

  } catch (error: any) {
    // Record failure
    await prisma.event.update({
      where: { id: eventId },
      data: { 
        status: job.attemptsMade >= (job.opts.attempts || 1) ? 'DEAD_LETTER' : 'FAILED',
        error: error.message,
        failedAt: new Date(),
        attempts: { increment: 1 }
      }
    });
    throw error; // Let BullMQ handle retry
  }
}

export function startEventProcessor() {
  console.log('Starting Event Processor worker...');
  const worker = new Worker<EventQueueJobData>(
    QUEUES.EVENTS,
    processEvent,
    { connection: redis }
  );

  worker.on('failed', (job, err) => {
    console.error(`Event Job ${job?.id} failed with error ${err.message}`);
  });
}
