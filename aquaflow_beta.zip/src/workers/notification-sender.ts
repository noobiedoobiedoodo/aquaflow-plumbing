import { Worker, Job } from 'bullmq';
import { prisma } from '../lib/db';
import { redis } from '../lib/queue/redis';
import { QUEUES, NotificationQueueJobData } from '../lib/queue/bullmq';

// Mocks or real SDKs depending on environment variables
// For MVP, we log if keys are missing
const RESEND_API_KEY = process.env.RESEND_API_KEY;
const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID;
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN;
const TWILIO_FROM_NUMBER = process.env.TWILIO_FROM_NUMBER || '+1234567890';

async function processNotification(job: Job<NotificationQueueJobData>) {
  const { notificationId } = job.data;
  
  const notification = await prisma.notification.findUnique({
    where: { id: notificationId },
    include: { organization: true, user: true }
  });

  if (!notification) throw new Error(`Notification ${notificationId} not found`);
  if (notification.status === 'DELIVERED') return; // Idempotency
  
  await prisma.notification.update({
    where: { id: notificationId },
    data: { status: 'PROCESSING', attempts: { increment: 1 } }
  });

  console.log(`Sending ${notification.channel} notification ${notification.id} to Customer/User...`);

  try {
    let providerId = null;

    if (notification.channel === 'EMAIL') {
      if (RESEND_API_KEY) {
        const { Resend } = await import('resend');
        const resend = new Resend(RESEND_API_KEY);
        // We assume we have customer email in metadata, or user email
        const metadata = JSON.parse(notification.metadata || '{}');
        const toEmail = metadata.email || 'customer@example.com'; // Defaulting for testing

        const res = await resend.emails.send({
          from: 'AquaFlow <onboarding@resend.dev>',
          to: toEmail,
          subject: notification.subject || 'New update from AquaFlow',
          text: notification.content,
          tags: [{ name: 'notificationId', value: notification.id }]
        });
        
        if (res.error) throw new Error(res.error.message);
        providerId = res.data?.id;
      } else {
        console.log(`[RESEND MOCK] Would send email to customer with subject: ${notification.subject}`);
        providerId = `mock_resend_${Date.now()}`;
      }
    } else if (notification.channel === 'SMS') {
      if (TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN) {
        const twilio = (await import('twilio')).default(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
        const metadata = JSON.parse(notification.metadata || '{}');
        const toNumber = metadata.phone || '+15555555555';

        const msg = await twilio.messages.create({
          body: notification.content,
          from: TWILIO_FROM_NUMBER,
          to: toNumber
        });
        
        providerId = msg.sid;
      } else {
        console.log(`[TWILIO MOCK] Would send SMS to customer: ${notification.content}`);
        providerId = `mock_twilio_${Date.now()}`;
      }
    }

    // Success - Sent to provider!
    // Note: It's 'SENT' not 'DELIVERED' because delivery is confirmed via webhooks later
    await prisma.notification.update({
      where: { id: notificationId },
      data: { 
        status: 'SENT', 
        sentAt: new Date(),
        providerId 
      }
    });

  } catch (error: any) {
    // Failure
    const isFinalFailure = job.attemptsMade >= (job.opts.attempts || 1);
    
    await prisma.notification.update({
      where: { id: notificationId },
      data: { 
        status: isFinalFailure ? 'FAILED' : 'PENDING',
        failureReason: error.message,
        failedAt: new Date()
      }
    });

    if (isFinalFailure) {
      await prisma.event.create({
        data: {
          organizationId: notification.organizationId,
          type: 'notification.failed',
          entityType: 'Notification',
          entityId: notification.id,
          data: JSON.stringify({ notificationId: notification.id, channel: notification.channel })
        }
      });
    }

    throw error;
  }
}

export function startNotificationSender() {
  console.log('Starting Notification Sender worker...');
  const worker = new Worker<NotificationQueueJobData>(
    QUEUES.NOTIFICATIONS,
    processNotification,
    { connection: redis }
  );

  worker.on('failed', (job, err) => {
    console.error(`Notification Job ${job?.id} failed with error ${err.message}`);
  });
}
