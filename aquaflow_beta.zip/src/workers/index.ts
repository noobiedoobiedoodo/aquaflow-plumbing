import { startOutboxDispatcher } from './outbox-dispatcher';
import { startEventProcessor } from './event-processor';
import { startNotificationSender } from './notification-sender';

// This is the entry point for the standalone worker process.
// Run this via something like `npx tsx src/workers/index.ts`

console.log('Bootstrapping AquaFlow Worker Process...');

startOutboxDispatcher();
startEventProcessor();
startNotificationSender();

console.log('All workers started successfully.');
