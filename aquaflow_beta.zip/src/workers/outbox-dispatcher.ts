import { prisma } from '../lib/db';
import { Queue } from 'bullmq';
import { eventsQueue } from '../lib/queue/bullmq';

async function dispatchOutbox() {
  console.log('Outbox Dispatcher running...');
  try {
    // 1. Fetch pending events
    // We use a transaction to safely claim events
    const dispatchedCount = await prisma.$transaction(async (tx) => {
      // Find up to 50 pending events
      const events = await tx.event.findMany({
        where: { status: 'PENDING' },
        take: 50,
        orderBy: { createdAt: 'asc' }
      });

      if (events.length === 0) return 0;

      // Claim them by updating status to PROCESSING
      const eventIds = events.map(e => e.id);
      await tx.event.updateMany({
        where: { id: { in: eventIds } },
        data: { status: 'PROCESSING' }
      });

      // Dispatch to BullMQ
      // If BullMQ fails here, the transaction rolls back and they remain PENDING
      const jobs = events.map(e => ({
        name: e.type,
        data: { eventId: e.id },
        opts: {
          jobId: e.id, // BullMQ idempotency key
          attempts: 5,
          backoff: { type: 'exponential', delay: 2000 }
        }
      }));

      await eventsQueue.addBulk(jobs);

      return events.length;
    });

    if (dispatchedCount > 0) {
      console.log(`Dispatched ${dispatchedCount} events to BullMQ.`);
    }
  } catch (error) {
    console.error('Error dispatching outbox events:', error);
  }
}

// Start polling
export function startOutboxDispatcher(intervalMs = 5000) {
  console.log(`Starting Outbox Dispatcher (interval: ${intervalMs}ms)`);
  setInterval(dispatchOutbox, intervalMs);
  // Initial run
  dispatchOutbox();
}
