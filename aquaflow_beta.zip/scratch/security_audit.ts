import { PrismaClient } from '@prisma/client';
import fetch from 'node-fetch';
import { randomBytes, createHash } from 'crypto';

const prisma = new PrismaClient();
const BASE_URL = 'http://localhost:3000';

function hashToken(token: string) {
  return createHash('sha256').update(token).digest('hex');
}

async function runAudit() {
  console.log("Starting Security Audit Matrix...");

  // 1. Setup Seed Data
  const org = await prisma.organization.create({ data: { name: 'Audit Org', slug: 'audit-org', timezone: 'UTC' } });

  const userA = await prisma.user.create({ data: { email: 'custA@audit.com', passwordHash: 'hash', firstName: 'CustA' } });
  const custA = await prisma.customer.create({ data: { userId: userA.id, organizationId: org.id, firstName: 'CustA', lastName: 'A' } });

  const userB = await prisma.user.create({ data: { email: 'custB@audit.com', passwordHash: 'hash', firstName: 'CustB' } });
  const custB = await prisma.customer.create({ data: { userId: userB.id, organizationId: org.id, firstName: 'CustB', lastName: 'B' } });

  const techUserA = await prisma.user.create({ data: { email: 'techA@audit.com', passwordHash: 'hash', firstName: 'TechA' } });
  const techA = await prisma.technician.create({ data: { userId: techUserA.id, organizationId: org.id, firstName: 'Tech', lastName: 'A' } });

  const techUserB = await prisma.user.create({ data: { email: 'techB@audit.com', passwordHash: 'hash', firstName: 'TechB' } });
  const techB = await prisma.technician.create({ data: { userId: techUserB.id, organizationId: org.id, firstName: 'Tech', lastName: 'B' } });

  const propA = await prisma.property.create({ data: { customerId: custA.id, organizationId: org.id, address: '123 Test', city: 'City', postalCode: '123' } });
  const propB = await prisma.property.create({ data: { customerId: custB.id, organizationId: org.id, address: '456 Test', city: 'City', postalCode: '456' } });

  const servA = await prisma.service.create({ data: { organizationId: org.id, name: 'S', slug: 's' } });
  const apptA = await prisma.appointment.create({ data: { customerId: custA.id, appointmentNumber: 'A1', propertyId: propA.id, serviceId: servA.id, organizationId: org.id, date: new Date(), startTime: '10:00', endTime: '11:00' } });
  const apptB = await prisma.appointment.create({ data: { customerId: custB.id, appointmentNumber: 'A2', propertyId: propB.id, serviceId: servA.id, organizationId: org.id, date: new Date(), startTime: '10:00', endTime: '11:00' } });

  const jobA = await prisma.job.create({ data: { appointmentId: apptA.id, organizationId: org.id, technicianId: techA.id, status: 'IN_PROGRESS' } });
  const jobB = await prisma.job.create({ data: { appointmentId: apptB.id, organizationId: org.id, technicianId: techB.id, status: 'IN_PROGRESS' } });

  const estA = await prisma.estimate.create({ data: { estimateNumber: 'EST-A', organizationId: org.id, jobId: jobA.id, customerId: custA.id, status: 'SENT' } });
  const estB = await prisma.estimate.create({ data: { estimateNumber: 'EST-B', organizationId: org.id, jobId: jobB.id, customerId: custB.id, status: 'SENT' } });

  const invA = await prisma.invoice.create({ data: { invoiceNumber: 'INV-A', organizationId: org.id, jobId: jobA.id, customerId: custA.id, status: 'SENT', dueDate: new Date(), paymentToken: 'pt_a' } });
  const invB = await prisma.invoice.create({ data: { invoiceNumber: 'INV-B', organizationId: org.id, jobId: jobB.id, customerId: custB.id, status: 'SENT', dueDate: new Date(), paymentToken: 'pt_b' } });

  const privatePhoto = await prisma.jobPhoto.create({ data: { jobId: jobA.id, uploadedById: techUserA.id, storageKey: 'private-photo.jpg', url: 'private-photo.jpg', customerVisible: false } });
  const publicPhoto = await prisma.jobPhoto.create({ data: { jobId: jobA.id, uploadedById: techUserA.id, storageKey: 'public-photo.jpg', url: 'public-photo.jpg', customerVisible: true } });

  // Mock sessions
  const custAToken = randomBytes(32).toString('base64url');
  await prisma.customerSession.create({ data: { customerId: custA.id, tokenHash: hashToken(custAToken), expiresAt: new Date(Date.now() + 100000) } });
  
  const techAToken = randomBytes(32).toString('base64url');
  await prisma.session.create({ data: { userId: techUserA.id, token: techAToken, expiresAt: new Date(Date.now() + 100000) } });
  await prisma.organizationMember.create({ data: { userId: techUserA.id, organizationId: org.id, role: 'TECHNICIAN' } });

  console.log("Seed data created.");

  let passed = 0;
  let failed = 0;

  async function assert(name: string, condition: boolean) {
    if (condition) {
      console.log(`✅ ${name}`);
      passed++;
    } else {
      console.error(`❌ ${name}`);
      failed++;
    }
  }

  try {
    // We will test page accesses via HTTP for auth assertions
    // Note: To test server actions effectively via script, we can hit the pages instead and check for 404/redirects.
    
    // Test 1: Customer A -> Customer A Job
    const r1 = await fetch(`${BASE_URL}/portal/jobs/${jobA.id}`, { headers: { cookie: `customer_session=${custAToken}` } });
    await assert('Customer A accesses Own Job (200)', r1.status === 200);

    // Test 2: Customer A -> Customer B Job
    const r2 = await fetch(`${BASE_URL}/portal/jobs/${jobB.id}`, { headers: { cookie: `customer_session=${custAToken}` } });
    await assert('Customer A accesses Customer B Job (404)', r2.status === 404);

    // Test 3: Customer A -> Private Job Photo
    const r3 = await fetch(`${BASE_URL}/api/files/${privatePhoto.storageKey}`, { headers: { cookie: `customer_session=${custAToken}` } });
    await assert('Customer A accesses Private Photo (403)', r3.status === 403 || r3.status === 404);

    // Test 4: Customer A -> Public Job Photo
    // Assuming the file doesn't actually exist on disk, we expect a 404 from the existsSync check, NOT a 403 Forbidden.
    const r4 = await fetch(`${BASE_URL}/api/files/${publicPhoto.storageKey}`, { headers: { cookie: `customer_session=${custAToken}` } });
    await assert('Customer A accesses Customer-visible Photo (404 File Not Found, not 403 Forbidden)', r4.status === 404 && r4.statusText === 'Not Found');

    // Test 5: Tech A -> Tech B Job File
    const r5 = await fetch(`${BASE_URL}/api/files/${publicPhoto.storageKey}`, { headers: { cookie: `plumber-session=${techAToken}` } });
    // Note: Job A belongs to Tech A. Let's test Tech A accessing Job B's file.
    const jobBPhoto = await prisma.jobPhoto.create({ data: { jobId: jobB.id, uploadedById: techUserB.id, storageKey: 'job-b-photo.jpg', url: 'job-b-photo.jpg' } });
    const r6 = await fetch(`${BASE_URL}/api/files/${jobBPhoto.storageKey}`, { headers: { cookie: `plumber-session=${techAToken}` } });
    await assert('Tech A accesses Tech B Job Photo (403)', r6.status === 403);

    // Test 6: Unauthenticated -> Private File
    const r7 = await fetch(`${BASE_URL}/api/files/${privatePhoto.storageKey}`);
    await assert('Unauthenticated accesses Private file (401)', r7.status === 401);

    // Test 7: Unauthenticated -> Customer Portal
    const r8 = await fetch(`${BASE_URL}/portal/dashboard`, { redirect: 'manual' });
    await assert('Unauthenticated accesses Customer portal (307 Redirect to login)', r8.status === 307);

  } catch (err) {
    console.error("Test execution failed:", err);
  }

  // Cleanup
  console.log("Cleaning up seed data...");
  await prisma.organization.delete({ where: { id: org.id } });

  console.log(`\nAudit Complete: ${passed} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

runAudit();
