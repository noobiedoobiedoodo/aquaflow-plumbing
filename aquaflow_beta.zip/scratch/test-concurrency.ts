import { PrismaClient } from '@prisma/client';
import { AutomationRulesEngine } from '../src/lib/automation/rules-engine';

const prisma = new PrismaClient();

async function runTests() {
  console.log("Starting Failure-Injection and Concurrency Tests...");
  
  const org = await prisma.organization.create({ data: { name: 'Test Org', slug: 'test-org', timezone: 'UTC' } });
  
  // Create a mock event
  const event = await prisma.event.create({
    data: {
      organizationId: org.id,
      type: 'test.event',
      entityType: 'Test',
      entityId: '123',
      data: JSON.stringify({}),
      status: 'PENDING'
    }
  });

  // Create an AutomationRule for this event
  const rule = await prisma.automationRule.create({
    data: {
      organizationId: org.id,
      name: 'TEST_CONCURRENCY_RULE',
      eventType: 'test.event',
      enabled: true,
      priority: 1
    }
  });

  // Since RULE_EXECUTORS in rules-engine won't have TEST_CONCURRENCY_RULE natively,
  // let's temporarily inject it or we can test another way. Wait, AutomationRulesEngine 
  // catches missing executors and throws an error, which still creates the AutomationExecution 
  // before throwing. So we can just check AutomationExecution counts!

  console.log("Simulating 5 concurrent workers processing the same event...");
  
  const promises = [];
  for(let i=0; i<5; i++) {
    promises.push(AutomationRulesEngine.evaluateEvent(event.id));
  }

  await Promise.allSettled(promises);

  // Assert exactly 1 AutomationExecution was created
  const executions = await prisma.automationExecution.findMany({
    where: { eventId: event.id, ruleId: rule.id }
  });

  if (executions.length === 1) {
    console.log("✅ Concurrency Test Passed: Exactly 1 AutomationExecution created despite 5 concurrent workers.");
  } else {
    console.error(`❌ Concurrency Test Failed: Found ${executions.length} executions.`);
  }

  // Cleanup
  await prisma.organization.delete({ where: { id: org.id } });
  console.log("Tests finished.");
}

runTests();
